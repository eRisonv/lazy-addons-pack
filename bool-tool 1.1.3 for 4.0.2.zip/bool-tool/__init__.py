# SPDX-License-Identifier: GPL-2.0-or-later

bl_info = {
    "name": "Bool Tool",
    "author": "Vitor Balbio, Mikhail Rachinskiy, TynkaTopi, Meta-Androcto, Simon Appelt",
    "version": (1, 1, 3),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Edit Tab",
    "description": "Bool Tool Hotkey: Ctrl Shift B",
    "doc_url": "{BLENDER_MANUAL_URL}/addons/object/bool_tools.html",
    "category": "Object",
}

import bpy
from .operators import register as operators_register, unregister as operators_unregister
from .tools import register as tools_register, unregister as tools_unregister
from . import (
    manual,
    preferences,
    properties,
    ui,
    versioning,
)


#### ------------------------------ REGISTRATION ------------------------------ ####

modules = [
    manual,
    preferences,
    properties,
    ui,
    versioning,
]

def register():
    for module in modules:
        module.register()

    operators_register()
    tools_register()

    preferences.update_sidebar_category(bpy.context.preferences.addons[__package__].preferences, bpy.context)


def unregister():
    for module in reversed(modules):
        module.unregister()

    operators_unregister()
    tools_unregister()
